import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

export const adminApi = createApi({
  reducerPath: "adminApi",
  baseQuery: fetchBaseQuery({ baseUrl: "http://localhost:9080/" }),
  endpoints: (builder) => ({
    getAdmin: builder.query({
      query: () => "Admin",
      providesTags: ["Admin"],
    }),
    addAdminData: builder.mutation({
      query: ({ value }) => ({
        url: "Admin",
        method: "POST",
        body: { value },
      }),
      invalidatesTags: ["Admin"],
    }),
    fetchAdminData: builder.query({
      query: () => "Admin/terms", 
      providesTags: ["Admin"],
    }),
  }),
});

export const { useGetAdminQuery, useAddAdminDataMutation ,useFetchAdminDataQuery} = adminApi;
