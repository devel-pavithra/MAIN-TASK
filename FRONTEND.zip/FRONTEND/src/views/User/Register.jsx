
import React from "react";
import Header from "../../components/Header/Header";
import "./user.scss";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import { useGetUsersQuery, useAddUserMutation } from "../../redux/api";

const Register = () => {
  const { data, isFetching, isError } = useGetUsersQuery();

  console.log(data);
  const [addUser] = useAddUserMutation();

  const navigate = useNavigate();

  const validationSchema = Yup.object().shape({
    UserName: Yup.string()
      .required("Username is required")
      .min(4, "Username must be at least 4 characters")
      .max(12, "Username must not exceed 12 characters")
      .matches(
        /^[a-zA-Z]*$/,
        "Username can only contain letters, numbers, underscores, and dots"
      ),
    email: Yup.string()
      .required("Email is required")
      .email("Email is invalid")
      .matches(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/g, "Must Be in Email Format"),
    password: Yup.string()
      .min(8, "Password must be at least 8 characters")
      .matches(
        /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$/g,
        "Password Should Matches This Condition"
      )
      .required("Password is required"),
    confirmPassword: Yup.string()
      .oneOf([Yup.ref("password"), null], "Passwords must match")
      .required("Confirm Password is required"),
  });




  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationSchema),
    mode: "onBlur",
  });

  const onSubmit = async (data) => {

    const result = await addUser(data)
    console.log(result);
    // const storedData = JSON.parse(localStorage.getItem("userDetails")) || [];

    // if (storedData.some((user) => user.UserName === data.UserName)) {
    //   Swal.fire({
    //     icon: "error",
    //     title: "Oops...",
    //     text: "Username already exists. Please choose a different one.",
    //   });
    //   return;
    // }

    // storedData.push(data);
    // localStorage.setItem("userDetails", JSON.stringify(storedData));

    Swal.fire({
      icon: "success",
      title: "Registration successful!",
      showConfirmButton: false,
      timer: 3000,
    }).then(() => {
      navigate(`/verify-email/${data.token}`);
    });
  };

  return (
    <>
      <Header />

      <div className="usrCrPg mycollectionSec">
        <div className="container">
          <h3 className="collectionSecHeading text-center">Register</h3>

          <div className="row mt-3 justify-content-center">
            <div className="col-lg-8 col-xl-6">
              <div className="createCollectionCard p-lg-4">
                <form className="w-100" onSubmit={handleSubmit(onSubmit)}>
                  <div className="form-group">
                    <div className="d-flex align-items-center flex-wrap">
                      <span className="formLabel">User Name</span>
                    </div>
                    <input
                      name="UserName"
                      type="text"
                      {...register("UserName")}
                      className={`form-control ${
                        errors.UserName ? "is-invalid" : ""
                      }`}
                      autoFocus
                    />
                    <div className="invalid-feedback">
                      {errors.UserName?.message}
                    </div>
                  </div>

                  <div className="form-group">
                    <div className="d-flex align-items-center flex-wrap">
                      <span className="formLabel">Email ID</span>
                    </div>
                    <input
                      name="email"
                      type="text"
                      {...register("email")}
                      className={`form-control ${
                        errors.email ? "is-invalid" : ""
                      }`}
                    />
                    <div className="invalid-feedback">
                      {errors.email?.message}
                    </div>
                  </div>

                  <div className="form-group">
                    <div className="d-flex align-items-center flex-wrap">
                      <span className="formLabel">Password</span>
                    </div>
                    <input
                      name="password"
                      type="password"
                      {...register("password")}
                      className={`form-control ${
                        errors.password ? "is-invalid" : ""
                      }`}
                    />
                    <div className="invalid-feedback">
                      {errors.password?.message}
                    </div>
                  </div>

                  <div className="form-group">
                    <div className="d-flex align-items-center flex-wrap">
                      <span className="formLabel">Confirm Password</span>
                    </div>
                    <input
                      name="confirmPassword"
                      type="password"
                      {...register("confirmPassword")}
                      className={`form-control ${
                        errors.confirmPassword ? "is-invalid" : ""
                      }`}
                    />
                    <div className="invalid-feedback">
                      {errors.confirmPassword?.message}
                    </div>
                  </div>

                  <div className="form-group pt-3 mb-0">
                    <button className="btn gradientBtn mx-auto" type="submit">
                      Register
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Register;
