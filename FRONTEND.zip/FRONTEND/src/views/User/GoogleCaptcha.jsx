import React, { useState } from 'react';
import ReCAPTCHA from 'react-google-recaptcha';
import { useForm } from 'react-hook-form';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Header from '../../components/Header/Header';
import './user.scss';
import { useNavigate } from 'react-router-dom';

const GoogleCaptcha = () => {
  const [isVerified, setIsVerified] = useState(false);
  const [showOtpModal, setShowOtpModal] = useState(false);
  const [otp, setOtp] = useState('');
  const navigate = useNavigate();

  const handleCaptchaChange = (value) => {
    setIsVerified(!!value);
  };

  const { handleSubmit } = useForm();

  const onSubmit = () => {
    if (isVerified) {
      toast.success('reCAPTCHA Verified', {
        position: 'top-center',
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
      });

      setShowOtpModal(true);
    } else {
      toast.error('Please verify reCAPTCHA', {
        position: 'top-center',
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
      });
    }
  };

  const closeOtpModal = () => {
    setShowOtpModal(false);
    setOtp(''); // Clear OTP input when closing the modal
  };

  const handleOtpChange = (e) => {
    const value = e.target.value.replace(/\D/g, '').slice(0, 4);
    setOtp(value);
  };

  const handleOtpSubmit = () => {
    if (/^\d{4}$/.test(otp)) {
      toast.success('OTP submitted successfully', {
        position: 'top-center',
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
      });

      // Perform additional logic if needed

      closeOtpModal();
      navigate('/settingskyc'); // Change this to the desired success route
    } else {
      toast.error('Please enter a valid 4-digit OTP', {
        position: 'top-center',
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: false,
        draggable: true,
      });
    }
  };

  return (
    <>
      <Header />

      <div className="usrCrPg mycollectionSec">
        <div className="container">
          <h3 className="collectionSecHeading text-center">Google reCAPTCHA</h3>

          <div className="row mt-3 justify-content-center">
            <div className="col-lg-8 col-xl-6">
              <div className="createCollectionCard p-lg-4">
                <form onSubmit={handleSubmit(onSubmit)}>
                  <ReCAPTCHA
                    sitekey="6Lev6RkpAAAAAPLINcqwnILONvFm-YkHYxpr-1O0"
                    onChange={handleCaptchaChange}
                  />
                  <button type="submit" className="btn btn-outline-success mt-3">
                    Submit
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* OTP Modal */}
      {showOtpModal && (
        <div className="otp-modal-square">
          <div className="otp-content-square">
            <span className="close" onClick={closeOtpModal}>
              &times;
            </span>
            <h2>Enter OTP</h2>
            <input
              type="text"
              maxLength="4"
              value={otp}
              onChange={handleOtpChange}
              placeholder="Enter 4-digit OTP"
            />
            <button  onClick={handleOtpSubmit} className="btn btn-outline-success mt-3">Submit OTP</button>
          </div>
        </div>
      )}

      {/* Toast Container */}
      <ToastContainer />
    </>
  );
};

export default GoogleCaptcha;
