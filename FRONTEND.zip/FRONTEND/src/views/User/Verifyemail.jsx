// VerifyEmail.js
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Header from "../../components/Header/Header";
import axios from "axios"; // You'll need Axios or another library for making API requests

const VerifyEmail = () => {
  const { token } = useParams();
  const [verificationStatus, setVerificationStatus] = useState("Verifying...");

  useEffect(() => {
    const verifyEmail = async () => {
      try {
        const response = await axios.post(
          // Replace with your backend API endpoint for email verification
          `${process.env.REACT_APP_API_BASE_URL}/verify-email`,
          { token }
        );

        if (response.data.success) {
          setVerificationStatus("Email verified successfully!");
        } else {
          setVerificationStatus("Email verification failed. Please try again.");
        }
      } catch (error) {
        console.error("Error verifying email:", error);
        setVerificationStatus("Error verifying email. Please try again.");
      }
    };

    verifyEmail();
  }, [token]);

  return (
    <>
      <Header />

      <div className="usrCrPg mycollectionSec">
        <div className="container">
          <h3 className="collectionSecHeading text-center">Verify Email</h3>

          <div className="row mt-3 justify-content-center">
            <div className="col-lg-8 col-xl-6">
              <div className="createCollectionCard p-lg-4">
                <p>{verificationStatus}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default VerifyEmail;
