
import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { Modal } from "react-bootstrap";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import Header from "../../components/Header/Header";
import "./user.scss";

const Login = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: "onBlur",
  });

  const [showModal, setShowModal] = useState(false);

  const onSubmit = async (data) => {
    // Retrieve stored user data from localStorage or initialize an empty array
    const storedData = JSON.parse(localStorage.getItem("userDetails")) || [];

    // Check if the provided email exists
    const matchedUser = storedData.find((user) => user.email === data.email);

    if (!matchedUser) {
      // If no matching user is found, display an error message
      toast.error("Email does not exist!", {
        position: "top-right",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
      return;
    }

    // Check if the provided password matches the stored password
    if (matchedUser.password === data.password) {
      // If there's a match, proceed with login
      toast.success("Login successful!", {
        position: "top-right",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
      setShowModal(true);
    } else {
      // If the password does not match, display an error message
      toast.error("Incorrect password!", {
        position: "top-right",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
    }
  };

  return (
    <>
      <Header />

      <div className="usrCrPg mycollectionSec">
        <div className="container">
          <h3 className="collectionSecHeading text-center">Login</h3>

          <div className="row mt-3 justify-content-center">
            <div className="col-lg-8 col-xl-6">
              <div className="createCollectionCard p-lg-4">
                <form className="w-100" onSubmit={handleSubmit(onSubmit)}>
                  {/* Email and Password fields */}
                  <div className="form-group">
                    <div className="d-flex align-items-center flex-wrap">
                      <span className="formLabel">Email ID</span>
                    </div>
                    <input
                      type="email"
                      placeholder="Enter Email Id"
                      className={`form-control ${
                        errors.email ? "is-invalid" : ""
                      }`}
                      {...register("email", {
                        required: "Email is required!",
                        pattern: /^\S+@\S+$/i,
                      })}
                    />
                    <div className="invalid-feedback">
                      {errors.email?.message}
                    </div>
                  </div>

                  <div className="form-group">
                    <div className="d-flex align-items-center flex-wrap">
                      <span className="formLabel">Password</span>
                    </div>
                    <input
                      type="password"
                      placeholder="Enter Password"
                      className={`form-control ${
                        errors.password ? "is-invalid" : ""
                      }`}
                      {...register("password", {
                        required: "Password is required!",
                      })}
                    />
                    <div className="invalid-feedback">
                      {errors.password?.message}
                    </div>
                  </div>

                  <div className="form-group pt-3 mb-0">
                    <button type="submit" className="btn gradientBtn mx-auto">
                      Login
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Toast Container */}
      <ToastContainer />
    </>
  );
};

export default Login;
