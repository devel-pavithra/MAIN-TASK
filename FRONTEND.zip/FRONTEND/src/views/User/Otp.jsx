import React, { useState } from 'react';

const OtpForm = () => {
  const [otp, setOtp] = useState(generateOtp());

  // Function to generate a random 6-digit OTP
  function generateOtp() {
    return Math.floor(100000 + Math.random() * 900000);
  }

  // Function to handle OTP regeneration
  const regenerateOtp = () => {
    setOtp(generateOtp());
  };

  return (
    <div>
      <h2>Enter OTP</h2>
      <p>Your OTP: {otp}</p>
      <button onClick={regenerateOtp}>Regenerate OTP</button>
      {/* Add your OTP input field and submit button here */}
    </div>
  );
};

export default OtpForm;
